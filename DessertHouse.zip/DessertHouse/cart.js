var openShopping = document.querySelector('.icon-cart');
var closeShopping = document.querySelector('.close');
var body = document.querySelector('body');
var list = document.querySelector('.list');
var listCard = document.querySelector('.cart-items');
var total = document.querySelector('.btn');
var quantity = document.querySelector('.quantity');

openShopping.addEventListener('click', ()=>{
    body.classList.add('active');
})
closeShopping.addEventListener('click', ()=>{
    body.classList.remove('active');
})

var cart = [];
var currentProductId = '';
        function showPopup(productId) {
            currentProductId = productId;
            document.getElementById('overlay').style.display = 'block';
            document.getElementById('popup').style.display = 'block';
        }

        function hidePopup() {
            document.getElementById('overlay').style.display = 'none';
            document.getElementById('popup').style.display = 'none';
        }

        function addToCart() {
            var quantity = document.getElementById('quantity').value;
            var product = {
                id: currentProductId,
                quantity: parseInt(quantity)
            };
            cart.push(product);
            console.log('Your Cart:', cart);
            updateCartDisplay();
            hidePopup();
        }

        function updateCartDisplay() {
            var cartItems = document.getElementById('cart-items');
            cartItems.innerHTML = ''; // Clear existing items

            cart.forEach(function(item) {
                var productElement = document.getElementById(item.id);
                var productName = productElement.querySelector('.product-info h2').innerText;
                var productPrice = productElement.querySelector('.product-info p:nth-of-type(2)').innerText;

                var cartItem = document.createElement('div');
                cartItem.classList.add('cart-item');
                cartItem.innerHTML = `
                    <p>${productName} - ${productPrice} - Quantity: ${item.quantity}</p>
                `;
                cartItems.appendChild(cartItem);
            });
        }
        
        document.getElementById('add-to-cart-btn').addEventListener('click', addToCart);
 